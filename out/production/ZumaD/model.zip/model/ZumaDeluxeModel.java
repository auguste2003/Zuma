package model;

import processing.core.PImage;
import processing.core.PVector;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;

import static java.lang.Math.min;

/**
 * The logic of me game
 */
public class ZumaDeluxeModel implements IZumaDeluxeModel{

    /**
     * some parameter related to the logic
     */
    private final int HEIGTH;
    private final int WIDTH;
    private Player player1;
    private GameState gameState;
   private LinkedList<Ball>   movingBalls = new LinkedList<Ball>(); // Balles en mouvement (Moving balls)


   LinkedList<Ball> projectiles = new LinkedList<Ball>(); // Objekte , die der Player projektiert
    int pokemonSize = 47; // Size von den Objekten

    float projectileSpeed = 20;
    int ballSpeed =2;

    int numTypes = 4; // Anzahl von Objektarten

    Random random = new Random();

Ball ball;
Ball projectil;

    //  LinkedList<Ball> movingBalls; // Balles en mouvement (Moving balls)

    int ballSize = 47;
    int ballStepDown = 80; // Abstand
    int numMovingBalls = 5; // Nombre total de balles (Total number of balls)
    int ballSpacing = 47; // Espacement entre les balles (Spacing between balls)
    int  previewType = random.nextInt(numTypes);; // Type de projectile de prévisualisation

    PImage[] objectImage = new PImage[4]; // Tableau pour stocker les images des Pokémon
    int numTypesOfPokemon = 4; // Nombre de types de Pokémon
    String[] images;
    LinkedList<Ball> otherBalls;

    /**
     * constructor to initialise the parameters
     * @param width
     * @param height
     */
    public ZumaDeluxeModel(int width, int height) {
        this.HEIGTH = height;
        this.WIDTH = width;
        startNewGame();
        this.gameState = GameState.START;

    }

    public LinkedList<Ball> getMovingBalls() {
        return movingBalls;
    }
    public LinkedList<Ball> getProjectiles(){
        return projectiles;
    }

    public void setMovingBalls(LinkedList<Ball> movingBalls) {
        this.movingBalls = movingBalls;
    }

    /**
     * start a new game
     */

    public void startNewGame( ){
        // Ball ausgeben

        player1 = new Player(this.WIDTH,this.HEIGTH);
        previewType = random.nextInt(numTypes);
        // Charger les images des Pokémon
        images = new String[numTypesOfPokemon];
        images[0]="images/electrode3.png";
        images[1]= "images/100.png" ;
        images[2]= "images/electrode2.png" ;
        images[3]=  "images/electrode.png";

        // Ajouter des Pokémon en mouvement à la liste
        for (int i = 0; i < numMovingBalls; i++) {
          //  movingBalls =new LinkedList<Ball>();
            int pokemonType = (int) (Math.random()*numTypesOfPokemon ); // Choisir un type de Pokémon au hasard
            ball = new Ball(i * -ballSpacing, 40,new XYTupel(5,0), pokemonType,ballSize,false,ballStepDown,2,600,800);
            ball.toString();
         //   ball.move();

                ball.setUrlImage(images[pokemonType]); // Ein URL für das Laden setzen


           // ball.move();
            addBall(ball);// On repousse chaque fois le x de la balle vers l'ariere

//System.out.println("move ball");
        }     //   moveBalls();
    }

    public String getImages(int numTypes) {
        return images[numTypes];
    }
    public int getPreviewType(){
        return previewType;
    }

    /**
     * La methode cree des balles en fonction des url des differents types de balles
     * @param movingBalls
     */
    public void moveBalls(LinkedList<Ball> movingBalls) {

            for (int i = movingBalls.size() - 1; i >= 0; i--) {
                if (!movingBalls.get(i).shouldDisappear()) {
                movingBalls.get(i).move();
            //    System.out.println("Move Balls");
                System.out.println(movingBalls.get(i).getTimesTouchedEdge());

            }else{
                    movingBalls.remove(i);
                }

        }
    }


public void addBall(Ball ball ){


    movingBalls.add(ball);// On repousse chaque fois le x de la balle vers l'ariere
  //  System.out.println("Add new Ball ");
    System.out.println(movingBalls);
}

    /**
     * la methode cree des projectiles a travers les cordonees de la souris
     * @param x
     * @param y
     */
    public void createProjectiles(float x , float y){
     //   System.out.println("Projectil");
    // Utilisez previewType pour le projectile qui sera lancé
    XYTupel vektor = new XYTupel(x,y); // Vitesse de propagation
    XYTupel dir = vektor.sub(vektor,player1.getPosition());
    dir.normalize();
    dir.mult(20);

 //   System.out.println(previewType);
System.out.println(player1.getPosition().getX());
  //  projectil = new Ball(this.player1.getPosition().getX(), this.player1.getPosition().getY(),new XYTupel(0,0), previewType,pokemonSize,true,ballStepDown,2,600,800);
 //   projectil = new Ball(this.player1.getPosition().getX(), this.player1.getPosition().getY(),dir, previewType,pokemonSize,true,ballStepDown,2,600,800);
    projectil = new Ball(this.player1.getPosition().getX(), this.player1.getPosition().getY(),dir, previewType,pokemonSize,true,ballStepDown,2,600,800);
    // projectil = new Ball(this.player1.getPosition().getX(), this.player1.getPosition().getY(), dir, previewType,pokemonSize,true,800,600);
    System.out.println(projectil);
    projectil.setUrlImage(images[previewType]); // Ein URL für das Laden setzen
projectiles.add(projectil); // ajoute aux projectiles
  //  System.out.println(projectiles);
 //   System.out.println("fügt Projektil");  // Prüfen ob das Projektil hinzugfügt werden ist

    previewType = random.nextInt(numTypes);
 //   System.out.println(previewType);
}

    /**
     * La methode deplace les projectiles en fonction du clic de la souris et les projecte dans le sens d'orientation du joueur
     * @param projectils
     */
    public void moveProjektil(LinkedList<Ball> projectils){
      //  System.out.println("Move projectiles");
    for (int i = projectils.size() - 1; i >= 0; i--) {

        Ball p = projectils.get(i);
        if (!p.isOffScreen()) {
            p.move();
        }else {

            projectils.remove(i);
        //    System.out.println("remove projectiles");
        }
    }
}

    /**
     *
     * @return
     */

    public void handleCollisions(LinkedList<Ball> movingBalls,LinkedList<Ball> projectiles) {
        for (int i = projectiles.size() - 1; i >= 0; i--) {
            Ball projectile = projectiles.get(i); // Projektile
           // for (int j = movingBalls.size() - 1; j >= 0; j--) {
            for (int j = 0; j < movingBalls.size(); j++) {
                Ball ball = movingBalls.get(j); // Une Balle de la liste

                    if (ball.collidesWith(projectile)) {

                        // Trouver la position d'insertion correcte
                        System.out.println("Colision " + ball.getType() + ": (x,y) =" + "(" + ball.getPosition().getX() + "," + ball.getPosition().getY() + ")" + " \n" + " mit Pokemon "
                                + projectile.getType() + ": (x,y) =" + "(" + ball.getPosition().getX() + "," + ball.getPosition().getY() + ")");

/*

System.out.println("Projektile");
System.out.println(projectile);

                        projectiles.remove(projectile);
                        System.out.println(movingBalls);
                        System.out.println(movingBalls.size());
                        System.out.println(projectiles);
                        System.out.println(projectiles.size());


                        System.out.println(movingBalls);
                        */
 System.out.println(movingBalls);
// hier zähle ich wieviele Objekte ähnlich zu dem Projektil an dieser Stelle vorkommen
                        int sameTypeStart = j;
                        int sameTypeEnd = j;
                        /*
                        * ici je determine le nombre de balles de meme type a la postion de la colission
                        * */
                    //    int type = movingBalls.get(j).getType();
                        int type = ball.getType();
                        if (projectile.getType() == type) {
                            movingBalls.add(j, projectile); // Da füge ich zuerst das Projektil
                            while (sameTypeStart > 0 && movingBalls.get(sameTypeStart - 1).getType() == type) {
                                sameTypeStart--; // nach links zählen
                                System.out.println(j);
                                System.out.println("nombre de balles similaires a gauche " + sameTypeStart);
                            }

                            while (sameTypeEnd < movingBalls.size() - 1 && movingBalls.get(sameTypeEnd + 1).getType() == type) {
                                sameTypeEnd++; // nach recht  zählen
                                System.out.println(j);
                                System.out.println("nombre de balles similaires a droite " + sameTypeEnd);
                            }

                            if (sameTypeEnd - sameTypeStart >= 2) { // Wenn es mehr als drei insgesamt sind , entferne ich sie
                                //        float gapDistance = (sameTypeEnd - sameTypeStart + 1) * pokemonSize + 25;

                                for (int a = sameTypeEnd; a >= sameTypeStart; a--) {
                                    movingBalls.remove(a);
                                }
                            }
                        } else if (projectile.getType() != ball.getType()) { // Si les types sont plutot differents j'ajoute la la postion de colision

                            // Créez une nouvelle balle avec les propriétés du projectile
                            //   Ball newBall = new Ball(projectile.position.x, projectile.position.y, projectile.type,ballSize,ball.velocity);
                       //     System.out.println(movingBalls);
                     //   projectile.setIprojectile(true);
                            // Ajoutez la nouvelle balle à la liste
                      //      movingBalls.add(j+1, projectile);
                      //      System.out.println(movingBalls);

/*
 * Je cree une nouvelle balle avec les attributs du projectil et je l'ajoute a la liste
 */
                            Ball  previewsBall = new Ball(ball.getPosition().getX()+ballSize, ball.getPosition().getY(),ball.getVelocity(), projectile.getType(),ballSize,false,ballStepDown,2,600,800);
                            previewsBall.setUrlImage(projectil.getUrlImage());
                            int k =0; // L#objectif ici est de decaler les balles vers l'avant a partir de la postion de colision
                            while (k<movingBalls.size()) {
                                if(k>j+1) {
                                    movingBalls.get(k).getPosition().setX(movingBalls.get(k).getPosition().getX() + ballSize);
                                    movingBalls.get(k).setUrlImage(movingBalls.get(k).getUrlImage());
                                }else {
                                    movingBalls.get(k).getPosition().setX(movingBalls.get(k).getPosition().getX() );
                                    movingBalls.get(k).setUrlImage(movingBalls.get(k).getUrlImage());
                                }
                                k++;

                            }

                            movingBalls.add(j+1,previewsBall);
                            projectiles.remove(projectile); // Retirer apres la collision
                        }

                        System.out.println(projectiles);
                        break; // Sortir de la boucle pour éviter de vérifier les collisions avec d'autres balles

                    }

             //   }
                }
            }

        }

    public Player getPlayer1() {
        return player1;
    }

    @Override
    public GameState getGameState() {
        return gameState;
    }

    @Override
    public void setGameState(GameState state) {
        this.gameState = state;
    }
}
