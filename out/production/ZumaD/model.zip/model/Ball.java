package model;



import processing.core.PApplet;
import processing.core.PImage;
import processing.core.PVector;

import java.util.LinkedList;
import java.util.Random;

import static java.lang.Math.max;

public class Ball {
   private  float height;
   private  float width;
   private  float ballStepDown ;
  private   int speedIncrement ;
  private   int   timesTouchedEdge;
  private   XYTupel position;
  private XYTupel velocity;
  private int type;
  private boolean isProjectile;
  private float size;
    private String urlImage;

    // Constructeur modifié pour prendre un type de Pokémon , type de balles
   public  Ball(float x, float y, XYTupel velocity, int type, float size, boolean isProjectile, float ballStepDown, int speedIncrement, float height, float width) {
        //super(x, y,velocity, type,size,isProjectile);
        position = new XYTupel(x, y);
        this.velocity = velocity; // Direction et vitesse du projectile
        this.type = type;
        this.isProjectile = isProjectile; // C'est un projectile
        this.size = size; // Taille de la balle
        this.ballStepDown =   ballStepDown;
        this.speedIncrement =speedIncrement;
        timesTouchedEdge =0;
        this.height =height;
        this.width=width;
   }

    public int getTimesTouchedEdge() {
        return timesTouchedEdge;
    }

    public float getSize() {
        return size;
    }

    public int getType() {
        return type;
    }

    public void setSize(float size) {
        this.size = size;
    }

    public XYTupel getPosition(){
       return position;
    }

    /**
     * Methode pour deplacer la balle en fonction d'une vitesse donnee
     */
    void move() {
        if(!this.isProjectile) {
            position.add(this.velocity);
            // Pour les balles en mouvement (pas les projectiles) (For moving balls, not projectiles)
            if (this.velocity.getY() == 0) {// on verifie encore que la balle se deplace verticalement
                // Changer de direction et descendre lorsqu'on touche un bord (Change direction and move down when touching an edge)
                if ((position.getX() > width && velocity.getX() > 0) || (position.getX() < 0 && velocity.getX() < 0)) {
                    ///  position.x = constrain(position.x, 0, width); // setzt position.x zwischen 0 und width
                    //    position.y += this.ballStepDown;
                    //     velocity.x *= -1; // Inverser la direction (Reverse the direction)
                    position.moveY(this.ballStepDown);
                    velocity.changeOrienX();
                    timesTouchedEdge++; // augmente le nombre de fois que ca touche les bords
                }
            }
        }else{
            System.out.println("Ist not projectil");
            this.position.add(this.velocity);
        }
    }

    public boolean getIsProjectile() {
        return isProjectile;
    }

    public void setProjectile(boolean projectile) {
        isProjectile = projectile;
    }

    public void setVelocity(XYTupel velocity) {
        this.velocity = velocity;
    }

    public void setPosition(XYTupel position) {
        this.position = position;
    }

    public XYTupel getVelocity() {
        return velocity;
    }

    public void setIprojectile(boolean projectile) {
        isProjectile = projectile;
    }

    public void setUrlImage(String urlImage){
        this.urlImage=urlImage;
    }
    public String getUrlImage(){
        return urlImage;
    }

    /**
     * La balle doit disparaitre lors qu'elle touche le bord de la fenetre 3 fois
     * @return
     */
    boolean shouldDisappear() {
        // Disparaître après avoir touché les bords trois fois (Disappear after touching the edges three times)
        return timesTouchedEdge >= 3;
    }
    boolean isOffScreen() {
        // Disparaître si la balle est hors de l'écran (pour les projectiles) (Disappear if the ball is off-screen, for projectiles)
        return position.getY() < 0 || position.getY() > height || position.getX() < 0 || position.getX() > width;
    }

    /**
     * verifie si la balle est en colision avec une autre
     * @param ball
     * @return
     */
    boolean collidesWith(Ball ball) {
System.out.println("Kollision");
            float dist = this.position.dist(ball.position);


        return dist < (ball.size / 2 + this.size / 2);

    }

    public String toString() {
        return "Ball : Position :"+"(" + this.position.getX() + "," + this.position.getY() + ") "+ "Velocyty :"+this.velocity+
                "type :"+this.type+" size :"+this.size+"isProjectile :"+this.isProjectile;
    }
}