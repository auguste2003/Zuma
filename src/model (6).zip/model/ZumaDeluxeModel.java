package model;

import java.util.LinkedList;
import java.util.Random;



/**
 * The logic of me game
 */
public class ZumaDeluxeModel implements IZumaDeluxeModel{
    /**
     * some parameter related to the logic
     */
    private final int HEIGTH;
    private final int WIDTH;
    private Player player1;
    private GameState gameState;
    private LinkedList<Ball>   movingBalls = new LinkedList<Ball>(); // Balles en mouvement (Moving balls)
    LinkedList<Ball> projectiles = new LinkedList<>(); // Objekte , die der Player projektiert
  private   int pokemonSize = 47; // Size von den Objekten
  private   int numTypes = 4; // Anzahl von Objektarten
   private  Random random = new Random();
   private  Ball ball;
    int ballStepDown = 80; // Abstand
    private  int  previewType = random.nextInt(numTypes);; // Type de projectile de prévisualisation

   private  float NewBallx =0; // pour la ball qui seras ajoutee
   private  float NewBally =0;

  private   int ballSize = 47;

   private  int numMovingBalls = 6; // Nombre total de balles (Total number of balls)
   private  int ballSpacing = 47; // Espacement entre les balles (Spacing between balls)

     private   XYTupel projectylVelocity;

    private int numTypesOfPokemon = 4; // Nombre de types de Pokémon
    private int insertionsstelle ;
private Ball projectil;
private  Ball  previewsBall;
    /**
     * constructor to initialise the parameters
     * @param width
     * @param height
     */
    public ZumaDeluxeModel(int width, int height) {
        this.HEIGTH = height;
        this.WIDTH = width;
        startNewGame();
        this.gameState = GameState.START;

    }

    public LinkedList<Ball> getMovingBalls() {
        return movingBalls;
    }
    public LinkedList<Ball> getProjectiles(){
        return projectiles;
    }

    /**
     * start a new game
     */

    public void startNewGame( ){
        // Ball ausgeben
System.out.println("Game starts!");
        player1 = new Player(this.WIDTH,this.HEIGTH);
        previewType = random.nextInt(numTypes);
        // Charger les images des Pokémon
        // Ajouter des Pokémon en mouvement à la liste
        for (int i = 0; i < numMovingBalls; i++) {
            int pokemonType = (int) (Math.random()*numTypesOfPokemon ); // Choisir un type de Pokémon au hasard
            ball = new Ball(i * -ballSpacing, 40,new XYTupel(1,0), pokemonType,ballSize,0,false,ballStepDown,2,600,800);
            ball.toString();
            addBall(ball);// On repousse chaque fois le x de la balle vers l'ariere
        }
        System.out.println(movingBalls);
    }


    public int getPreviewType(){
        return previewType;
    }
    /**
     * La methode cree des balles en fonction des url des differents types de balles

     */
    public void moveBalls() {

        for (int i = movingBalls.size() - 1; i >= 0; i--) {
            if (!movingBalls.get(i).shouldDisappear()) {
                movingBalls.get(i).move();
            }else{
                movingBalls.remove(i);
            }
        }
    }


    public void addBall(Ball ball ){
        movingBalls.add(ball);// On repousse chaque fois le x de la balle vers l'ariere
    }
public XYTupel calculateProhectilVelocity(float x, float y){
    XYTupel vektor = new XYTupel(x,y); // Vitesse de propagation
    XYTupel dir = vektor.sub(vektor,player1.getPosition());
    dir.normalize();
    dir.mult(20);
    return dir;
}

    public XYTupel getProjectylVelocity() {
        return projectylVelocity;
    }

    public void setProjectylVelocity(XYTupel projectylVelocity) {
        this.projectylVelocity = projectylVelocity;
    }

    /**
     * la methode cree des projectiles a travers les cordonees de la souris

     */

    public void createProjectiles() {
        //   System.out.println("Projectil");
        // Utilisez previewType pour le projectile qui sera lancé
     /*   XYTupel vektor = new XYTupel(x,y); // Vitesse de propagation
        XYTupel dir = vektor.sub(vektor,player1.getPosition());
        dir.normalize();
        dir.mult(20);
*/
       projectil = new Ball(this.player1.getPosition().getX(), this.player1.getPosition().getY(), new XYTupel(1,0), previewType, pokemonSize, 0, true, ballStepDown, 2, 600, 800);


        System.out.println("erzeugter Projektil : " + projectil);
        projectiles.add(projectil); // ajoute aux projectiles
        previewType = random.nextInt(numTypes);
    }
public Ball getProjectil(){
        return projectil;
}
    /**
     * La methode deplace les projectiles en fonction du clic de la souris et les projecte dans le sens d'orientation du joueur

     */
    public void moveProjektil(int projectilTyp ,int stelle){
        System.out.println("Stelle : "+stelle +" und "+movingBalls.size());
if(stelle < movingBalls.size()) {
    if (projectil.getVelocity().getX() == movingBalls.get(stelle).getVelocity().getX()) {
        if (projectilTyp != projectil.getType()) {
            System.out.println("falscher Projektil");
        }
        System.out.println(movingBalls);
        projectil.getPosition().setX(movingBalls.get(stelle).getPosition().getX());
        projectil.getPosition().setY(40);
        System.out.println(projectil);
        this.handleCollisions(stelle);
    }

    for (int i = projectiles.size() - 1; i >= 0; i--) {
        Ball p = projectiles.get(i);

        if (!p.isOffScreen() && p.getType() == projectilTyp && p.getVelocity().getX() != movingBalls.get(stelle).getVelocity().getX()) {
            p.move();
        } else {
            projectiles.remove(i);
        }
    }

    this.handleCollisions(stelle);
}
    }
    public void moveProjektiles(int stelle){
          System.out.println("Move projectiles to "+stelle);
        this.CheckNumberAndRemoveBalls(projectil.getType(),stelle);
        System.out.println(movingBalls);
    }
    /**
     *
     * @return
     */

    public void handleCollisions( int stelle ) {
        for (int i = 0; i < projectiles.size(); i++) {
            Ball projectile = projectiles.get(i);
            int collisionIndex = CheckCollision(projectile);
            if (collisionIndex != -1 && collisionIndex == stelle) {
               createSpaceForPreviewsBall(projectile.getType(), collisionIndex);
               // CheckNumberAndRemoveBalls(projectile.getType(), collisionIndex);
                projectiles.remove(projectile); // Entfernen des Projektils nach der Verarbeitung
               i--; // Korrektur des Index nach dem Entfernen eines Elements
           }
        }
    }

    public int getInsertionsstelle() {
        return insertionsstelle;
    }
// Ajouter un parametre pour la position du projectile

    private int CheckCollision(Ball projectile) {
        for (int i = 0; i < movingBalls.size(); i++) {
            // verifie pour chaque balle s'il y'a collision
            if (projectile.collidesWith(movingBalls.get(i))) {
                insertionsstelle = i;
                System.out.println("Ball "+movingBalls.get(i).getType()+" an der Stelle "+i+" getroffen");
                return i; // Rückgabe des Index des kollidierten Balls
            }
        }
        return -1; // Keine Kollision erkannt
    }

    public void createSpaceForPreviewsBall(int trojektiltyp, int collisionIndex) {
        // Einfügen des Projektils an der Kollisionsstelle
        Ball BallInIndex = movingBalls.get(collisionIndex);
// Annahme: i ist die Startposition, ab der du die Bälle verschieben möchtest
        int i = collisionIndex; // Beispielstartposition
// Überprüfe, ob die Startposition i gültig ist
        if (i >= 0 && i < movingBalls.size() - 1) {
            float currentX =0;
            float currentY =0;
            // Iteriere über alle Bälle ab der Startposition i
            for (int j = i; j <movingBalls.size(); j++) {
                // Hole den Ball an Position j
                Ball ballAtPositionJ = movingBalls.get(j);
                // Überprüfe, ob der Ball an Position j existiert
                if (ballAtPositionJ != null) {
                    // Hole die aktuellen Koordinaten des Balls an Position j
                    currentX = ballAtPositionJ.getPosition().getX();
                    currentY = ballAtPositionJ.getPosition().getY();

                    // Verschiebe die x-Koordinate um eine Position nach rechts
                  /*      if (ballAtPositionJ.getVelocity().getX() > 0) {
                            currentX -= ballSize;
                        } else {
                             currentX += ballSize;
                        } */
                    if ( ballAtPositionJ.getVelocity().getX()>0) {
                        currentX -= ballSize;
                        currentY =40;
                    } else if (ballAtPositionJ.getVelocity().getY()>0) {
                        currentY -=ballSize;
                    }


                    // Aktualisiere die Koordinaten des Balls
                    ballAtPositionJ.setPosition(new XYTupel(currentX, currentY));
                } else {
                    System.out.println("Ball an Position " + j + " existiert nicht.");
                }
            }
        } else {
            System.out.println("Ungültige Startposition " + i);
        }

/*
* else if (BallInIndex.getVelocity().getY() > 0) {
            // Wenn sich der Ball vertikal nach unten bewegt
            NewBallx = BallInIndex.getPosition().getX();
            NewBally = BallInIndex.getPosition().getY() + ballSize;
        }
* */
        if (BallInIndex.getVelocity().getX() > 0 ) {
            System.out.println("X von Ballindex "+BallInIndex.getPosition().getX());
            System.out.println("Y von Ballindex "+BallInIndex.getPosition().getY());
            // Wenn sich der Ball horizontal nach rechts bewegt
            NewBallx = BallInIndex.getPosition().getX() + ballSize;
            NewBally = BallInIndex.getPosition().getY();

        } else if (BallInIndex.getVelocity().getY() > 0 ) {
            NewBallx = BallInIndex.getPosition().getX();
            NewBally = BallInIndex.getPosition().getY()+ballSize;
        }
     /*   if (  movingBalls.get(collisionIndex).getVelocity().getX() > 0  ) {
    NewBallx = movingBalls.get(collisionIndex).getPosition().getX() + ballSize;

    NewBally = 40;
        }
        if (movingBalls.get(collisionIndex).getVelocity().getY() >0){
          //  previewsBall.getPosition().setY(40);
            // } else if(BallInIndex.getVelocity().getY() != 0 && BallInIndex.getVelocity().getX() == 0 && BallInIndex.getVelocity().getY()>0) {
        }
*/
        // Überprüfen und Entfernen von übereinstimmenden Bällen
       CheckNumberAndRemoveBalls(trojektiltyp,collisionIndex);
    }
    // Méthode pour fermer les écarts après la suppression des balles
    private void closeGaps(int startIndex, int numBallsToRemove ) {
        float gapDistance = (numBallsToRemove)*ballSize;
        // Fermez l'écart en déplaçant les balles à partir de l'indice de début
        for (int i = startIndex; i < movingBalls.size(); i++) {
            Ball ball = movingBalls.get(i);
            if (ball.getVelocity().getX() > 0) {
                ball.getPosition().moveX(gapDistance);
            }
if(ball.getVelocity().getY()>0){
    ball.getPosition().moveY(gapDistance);
}
        }
    }
    private void CheckNumberAndRemoveBalls(int type,int startIndex) {
          previewsBall = new Ball(NewBallx, NewBally,movingBalls.get(startIndex).getVelocity(), type,ballSize,movingBalls.get(startIndex).getTimesTouchedEdge(),movingBalls.get(startIndex).getIsProjectile(),ballStepDown,2,600,800);

         movingBalls.add(startIndex, previewsBall);

        System.out.println("Projektil "+previewsBall.getType()+" an der Stelle "+startIndex+" hinzugefügt");
        System.out.println(movingBalls);
        int endIndex = startIndex;
        int ballType = movingBalls.get(startIndex).getType();
        // Nach links suchen, um übereinstimmende Bälle zu finden
        while (startIndex > 0 && movingBalls.get(startIndex - 1).getType() == ballType) {
            startIndex--;
        }
        // Nach rechts suchen, um übereinstimmende Bälle zu finden
        while (endIndex < movingBalls.size() - 1 && movingBalls.get(endIndex + 1).getType() == ballType) {
            endIndex++;
        }
        // Überprüfen, ob genug Bälle zum Entfernen vorhanden sind (mindestens 3)
        if (endIndex - startIndex >= 2) {
            // Entfernen der übereinstimmenden Bälle
            System.out.print("Bälle entfernt :");
            for (int i = endIndex; i >= startIndex; i--) {
                System.out.println(movingBalls.get(i)+" , ");
                movingBalls.remove(i);
            }
            // Aktualisieren der Positionen der verbleibenden Bälle
        }
        // Après la suppression, fermez les écarts
        if (endIndex - startIndex >= 2) {
            int numBallsToRemove = endIndex - startIndex + 1;
            closeGaps(startIndex, numBallsToRemove);
        }
    }
    public Player getPlayer1() {
        return player1;
    }
    public GameState getGameState() {
        return gameState;
    }
    public void setGameState(GameState state) {
        this.gameState = state;
    }
}