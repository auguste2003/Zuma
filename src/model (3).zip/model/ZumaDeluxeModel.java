package model;

import processing.core.PImage;
import processing.core.PVector;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;

import static java.lang.Math.min;

/**
 * The logic of me game
 */
public class ZumaDeluxeModel implements IZumaDeluxeModel{

    /**
     * some parameter related to the logic
     */
    private final int HEIGTH;
    private final int WIDTH;
    private Player player1;
    private GameState gameState;
   private LinkedList<Ball>   movingBalls = new LinkedList<Ball>(); // Balles en mouvement (Moving balls)


   LinkedList<Ball> projectiles = new LinkedList<Ball>(); // Objekte , die der Player projektiert
    int pokemonSize = 47; // Size von den Objekten

    float projectileSpeed = 80;
    int ballSpeed =2;

    int numTypes = 4; // Anzahl von Objektarten

    Random random = new Random();

Ball ball;
Ball projectil;

    //  LinkedList<Ball> movingBalls; // Balles en mouvement (Moving balls)

    int ballSize = 47;
    int ballStepDown = 80; // Abstand
    int numMovingBalls = 5; // Nombre total de balles (Total number of balls)
    int ballSpacing = 47; // Espacement entre les balles (Spacing between balls)
    int  previewType = random.nextInt(numTypes);; // Type de projectile de prévisualisation

    PImage[] objectImage = new PImage[4]; // Tableau pour stocker les images des Pokémon
    int numTypesOfPokemon = 4; // Nombre de types de Pokémon
    String[] images;
    LinkedList<Ball> otherBalls;

    /**
     * constructor to initialise the parameters
     * @param width
     * @param height
     */
    public ZumaDeluxeModel(int width, int height) {
        this.HEIGTH = height;
        this.WIDTH = width;
        startNewGame();
        this.gameState = GameState.START;

    }

    public LinkedList<Ball> getMovingBalls() {
        return movingBalls;
    }
    public LinkedList<Ball> getProjectiles(){
        return projectiles;
    }

    public void setMovingBalls(LinkedList<Ball> movingBalls) {
        this.movingBalls = movingBalls;
    }

    /**
     * start a new game
     */

    public void startNewGame( ){
        // Ball ausgeben

        player1 = new Player(this.WIDTH,this.HEIGTH);
        previewType = random.nextInt(numTypes);
        // Charger les images des Pokémon
        images = new String[numTypesOfPokemon];
        images[0]="images/electrode3.png";
        images[1]= "images/100.png" ;
        images[2]= "images/electrode2.png" ;
        images[3]=  "images/electrode.png";

        // Ajouter des Pokémon en mouvement à la liste
        for (int i = 0; i < numMovingBalls; i++) {
          //  movingBalls =new LinkedList<Ball>();
            int pokemonType = (int) (Math.random()*numTypesOfPokemon ); // Choisir un type de Pokémon au hasard
            ball = new Ball(i * -ballSpacing, 40,new XYTupel(5,0), pokemonType,ballSize,0,false,ballStepDown,2,600,800);
            ball.toString();
         //   ball.move();

                ball.setUrlImage(images[pokemonType]); // Ein URL für das Laden setzen


           // ball.move();
            addBall(ball);// On repousse chaque fois le x de la balle vers l'ariere

//System.out.println("move ball");
        }     //   moveBalls();
    }

    public String getImages(int numTypes) {
        return images[numTypes];
    }
    public int getPreviewType(){
        return previewType;
    }

    /**
     * La methode cree des balles en fonction des url des differents types de balles
     * @param movingBalls
     */
    public void moveBalls(LinkedList<Ball> movingBalls) {

            for (int i = movingBalls.size() - 1; i >= 0; i--) {
                if (!movingBalls.get(i).shouldDisappear()) {
                movingBalls.get(i).move();
            //    System.out.println("Move Balls");
                System.out.println(movingBalls.get(i).getTimesTouchedEdge());

            }else{
                    movingBalls.remove(i);
                }
        }
    }


public void addBall(Ball ball ){


    movingBalls.add(ball);// On repousse chaque fois le x de la balle vers l'ariere
  //  System.out.println("Add new Ball ");
    System.out.println(movingBalls);
}

    /**
     * la methode cree des projectiles a travers les cordonees de la souris
     * @param x
     * @param y
     */
    public void createProjectiles(float x , float y){
     //   System.out.println("Projectil");
    // Utilisez previewType pour le projectile qui sera lancé
    XYTupel vektor = new XYTupel(x,y); // Vitesse de propagation
    XYTupel dir = vektor.sub(vektor,player1.getPosition());
    dir.normalize();
    dir.mult(20);

 //   System.out.println(previewType);
System.out.println(player1.getPosition().getX());
  //  projectil = new Ball(this.player1.getPosition().getX(), this.player1.getPosition().getY(),new XYTupel(0,0), previewType,pokemonSize,true,ballStepDown,2,600,800);
 //   projectil = new Ball(this.player1.getPosition().getX(), this.player1.getPosition().getY(),dir, previewType,pokemonSize,true,ballStepDown,2,600,800);
    projectil = new Ball(this.player1.getPosition().getX(), this.player1.getPosition().getY(),dir, previewType,pokemonSize,0,true,ballStepDown,2,600,800);
    // projectil = new Ball(this.player1.getPosition().getX(), this.player1.getPosition().getY(), dir, previewType,pokemonSize,true,800,600);
    System.out.println(projectil);
    projectil.setUrlImage(images[previewType]); // Ein URL für das Laden setzen
projectiles.add(projectil); // ajoute aux projectiles
  //  System.out.println(projectiles);
 //   System.out.println("fügt Projektil");  // Prüfen ob das Projektil hinzugfügt werden ist

    previewType = random.nextInt(numTypes);
 //   System.out.println(previewType);
}

    /**
     * La methode deplace les projectiles en fonction du clic de la souris et les projecte dans le sens d'orientation du joueur
     * @param projectils
     */
    public void moveProjektil(LinkedList<Ball> projectils){
      //  System.out.println("Move projectiles");
    for (int i = projectils.size() - 1; i >= 0; i--) {

        Ball p = projectils.get(i);
        if (!p.isOffScreen()) {
            p.move();
        }else {

            projectils.remove(i);
        //    System.out.println("remove projectiles");
        }
    }
}

    /**
     *
     * @return
     */

    public void handleCollisions(LinkedList<Ball> movingBalls) {
        for (int i = 0; i < projectiles.size(); i++) {
            Ball projectile = projectiles.get(i);
            int collisionIndex = CheckCollision(projectile, movingBalls);
            if (collisionIndex != -1) {
                handleCollision(projectile, collisionIndex,movingBalls);
                projectiles.remove(i); // Entfernen des Projektils nach der Verarbeitung
                i--; // Korrektur des Index nach dem Entfernen eines Elements
            }
        }
    }



    private int CheckCollision(Ball projectile, LinkedList<Ball> movingBalls) {
        for (int i = 0; i < movingBalls.size(); i++) {
            // verifie pour chaque balle s'il y'a collision
            if (projectile.collidesWith(movingBalls.get(i))) {
                return i; // Rückgabe des Index des kollidierten Balls
            }
        }
        return -1; // Keine Kollision erkannt
    }

    private void handleCollision(Ball projectile, int collisionIndex,LinkedList<Ball> movingBalls) {
        // Einfügen des Projektils an der Kollisionsstelle
        Ball BallInIndex = movingBalls.get(collisionIndex);




// Annahme: i ist die Startposition, ab der du die Bälle verschieben möchtest
        int i = collisionIndex; // Beispielstartposition

// Überprüfe, ob die Startposition i gültig ist
        if (i >= 0 && i < movingBalls.size() - 1) {
            // Iteriere über alle Bälle ab der Startposition i
            for (int j = i; j <movingBalls.size(); j++) {

                // Hole den Ball an Position j
                Ball ballAtPositionJ = movingBalls.get(j);

                // Überprüfe, ob der Ball an Position j existiert
                if (ballAtPositionJ != null) {

                        // Hole die aktuellen Koordinaten des Balls an Position j
                        float currentX = ballAtPositionJ.getPosition().getX();
                        float currentY = ballAtPositionJ.getPosition().getY();

                        // Verschiebe die x-Koordinate um eine Position nach rechts
                  /*      if (ballAtPositionJ.getVelocity().getX() > 0) {
                            currentX -= ballSize;

                        } else {
                             currentX += ballSize;
                        } */
                    if (ballAtPositionJ.getVelocity().getX() != 0 && ballAtPositionJ.getVelocity().getY() == 0&& ballAtPositionJ.getVelocity().getX()>0) {

                        currentX -= ballSize;

                            currentY =40;


                    } else if(ballAtPositionJ.getVelocity().getY() != 0 && ballAtPositionJ.getVelocity().getX() != 0 && ballAtPositionJ.getVelocity().getY()>0) {
                        float X = ballAtPositionJ.getPosition().getX();
                        currentX =X;
                        currentY -= ballSize;
                    }

                        // Aktualisiere die Koordinaten des Balls
                        ballAtPositionJ.setPosition(new XYTupel(currentX, currentY));

                        // Optional: Drucke die aktualisierten Koordinaten
                        System.out.println("Neue Koordinaten des Balls an Position " + j + ": " + ballAtPositionJ.getPosition());


                } else {
                    System.out.println("Ball an Position " + j + " existiert nicht.");
                }
            }
        } else {
            System.out.println("Ungültige Startposition " + i);
        }

       float NewBallx =0;
float NewBally =0;

        if (BallInIndex.getVelocity().getX() != 0 && BallInIndex.getVelocity().getY() == 0 && BallInIndex.getVelocity().getX()>0) {
            NewBallx = BallInIndex.getPosition().getX()+ballSize;
            NewBally =40;

        } else if(BallInIndex.getVelocity().getY() != 0 && BallInIndex.getVelocity().getX() == 0 && BallInIndex.getVelocity().getY()>0) {
            NewBallx= BallInIndex.getPosition().getX();
            NewBally =BallInIndex.getPosition().getY()+ballSize;
          //  BallInIndex.getPosition().setY(NewBally-ballSize);
        }
        Ball  previewsBall = new Ball(NewBallx, NewBally,BallInIndex.getVelocity(), projectile.getType(),ballSize,BallInIndex.getTimesTouchedEdge(),BallInIndex.getIsProjectile(),ballStepDown,2,600,800);
        previewsBall.setUrlImage(projectile.getUrlImage());

       movingBalls.add(collisionIndex, previewsBall);
        System.out.println(previewsBall);
System.out.println(movingBalls);

        // Anpassen der Bewegungsrichtung des Projektils


        // Überprüfen und Entfernen von übereinstimmenden Bällen
      CheckNumberAndRemoveBalls(collisionIndex,movingBalls);
    }
    private void adjustProjectileProperties(Ball projectile, int collisionIndex,LinkedList<Ball> movingBalls) {
        // Annahme: Die Geschwindigkeit und Richtung des vorherigen Balls wird übernommen
        if (collisionIndex > 0) {
            Ball previousBall = movingBalls.get(collisionIndex - 1);
            projectile.setVelocity(previousBall.getVelocity());
            projectile.setTimesTouchedEdge(previousBall.getTimesTouchedEdge());
        }
    }
    private void CheckNumberAndRemoveBalls(int startIndex,LinkedList<Ball> movingBalls) {
        int endIndex = startIndex;
        int ballType = movingBalls.get(startIndex).getType();

        // Nach links suchen, um übereinstimmende Bälle zu finden
        while (startIndex > 0 && movingBalls.get(startIndex - 1).getType() == ballType) {
            startIndex--;
        }

        // Nach rechts suchen, um übereinstimmende Bälle zu finden
        while (endIndex < movingBalls.size() - 1 && movingBalls.get(endIndex + 1).getType() == ballType) {
            endIndex++;
        }

        // Überprüfen, ob genug Bälle zum Entfernen vorhanden sind (mindestens 3)
        if (endIndex - startIndex >= 2) {
            // Entfernen der übereinstimmenden Bälle
            for (int i = endIndex; i >= startIndex; i--) {
                movingBalls.remove(i);
            }

            // Aktualisieren der Positionen der verbleibenden Bälle
            //     updateBallPositions(startIndex,movingBalls);
        }
    }





    public Player getPlayer1() {
        return player1;
    }

    @Override
    public GameState getGameState() {
        return gameState;
    }

    @Override
    public void setGameState(GameState state) {
        this.gameState = state;
    }
}
