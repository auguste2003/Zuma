package model;

import processing.core.PImage;

import static java.lang.Math.atan2;
import static java.util.Collections.rotate;

public class Player {

    private XYTupel position;

    public Player(int width, int height) {
        this.position = new XYTupel((float)width/2, (float)height-50);
        System.out.println(position.getX());
        System.out.println(position.getY());
    }

    public XYTupel getPosition() {
        return position;
    }
    public float moveX(float x){
       return x-position.getX();
    }
    public float moveY(float y){
       return y -position.getY() ;
    }
}
